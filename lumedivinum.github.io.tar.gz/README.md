# lumedivinum.github.io
Pensamento Corporativo⠠⠵
